nand_prog
---------

This application will program the NAND flash with two applications.
The first application is the kickstart application (located in 
examples/kickstart) which is a simple bootloader. The kickstart
application will be stored in block 0 of the NAND flash.

The second application is an application of your choice. This 
application will be stored in block 1 and onwards, i.e., it
may be larger than one block.

The LPC3250 bootloader is able to boot an application stored
in block 0 (for a large page NAND flash the maximum size
may only be 54K). For this example that application will
be the kickstart application.

The Kickstart applications responsibility is then to load
a second application stored in block 1 and onwards.

The second application could, e.g., be a more advanced bootloader
such as u-boot or the application you would like to be started
when the board powers up.

By default the S1L bootloader will be used as the second 
application (examples/s1l). 

Bad block information
---------------------
The LPC3250 bootloader use the MLC controller to load
the application stored in block 0. We have therefore
decided to use that controller to read and write
application 1 & 2. 

The MLC has support for ECC (Error Correction) in HW,
but can only work with one small page at a time (528 bytes).

The NAND memory on the EA board is a LARGE page NAND (2112 bytes)
which means that one page will be divided into four sections
when using the MLC controller. By default bad block information
is stored at offset 2048 (i.e. first index in the spare area), but
since a page is divided into four sections that offset will be 
overwritten. 

This application will however copy any bad block information to
offset 2096 instead for blocks used by app 1 & 2.
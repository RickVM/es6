kickstart
---------

This is a simple bootloader typically stored in block 0
of the NAND flash. The responsibility of this application
is to load a second application that is stored in
block 1 and onwards in the NAND flash.

The first thing that will happen is that this application
will relocate itself to the end of the internal RAM. When
that has been done it will verify if an application is
present in block 1 and then load that application
into internal RAM starting at address 0x0. When the 
application has been loaded it will start the application.

The examples/nand_prog application can be used to program
the NAND flash with the kickstart and the s1l applications.


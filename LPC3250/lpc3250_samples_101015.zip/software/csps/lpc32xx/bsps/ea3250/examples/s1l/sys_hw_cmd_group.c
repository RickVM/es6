/***********************************************************************
 * $Id:: sys_hw_cmd_group.c 1274 2008-10-29 23:44:34Z wellsk           $
 *
 * Project: Command processor
 *
 * Description:
 *     Processes commands from the command prompt
 *
 ***********************************************************************
 * Software that is described herein is for illustrative purposes only  
 * which provides customers with programming information regarding the  
 * products. This software is supplied "AS IS" without any warranties.  
 * NXP Semiconductors assumes no responsibility or liability for the 
 * use of the software, conveys no license or title under any patent, 
 * copyright, or mask work right to the product. NXP Semiconductors 
 * reserves the right to make changes in the software without 
 * notification. NXP Semiconductors also make no representation or 
 * warranty that such application will be suitable for the specified 
 * use without further testing or modification. 
 **********************************************************************/

#include "lpc_string.h"
#include "sys.h"
#include "lpc32xx_clkpwr_driver.h"
#include "lpc32xx_emc.h"
#include "ea3250_board.h"
#include "s1l_cmds.h"
#include "s1l_line_input.h"
#include "s1l_sys_inf.h"


/* update command */
BOOL_32 cmd_update(void);
static UNS_32 cmd_update_plist[] =
{
	(PARSE_TYPE_STR | PARSE_TYPE_OPT), /* The "update" command */
	(PARSE_TYPE_STR | PARSE_TYPE_END)
};
static CMD_ROUTE_T hw_update_cmd =
{
	(UNS_8 *) "update",
	cmd_update,
	(UNS_8 *) "Updates the kickstart or the bootloader application",
	(UNS_8 *) "update <kick>",
	cmd_update_plist,
	NULL
};

/* hw group */
static GROUP_LIST_T hw_group =
{
	(UNS_8 *) "hw", /* hardware group */
	(UNS_8 *) "Hardware command group",
	NULL,
	NULL
};

#if 0
/* nrsv command */
BOOL_32 cmd_nrsv(void);
static UNS_32 cmd_nrsv_plist[] =
{
	(PARSE_TYPE_STR), /* The "nrsv" command */
	(PARSE_TYPE_DEC),
	(PARSE_TYPE_DEC | PARSE_TYPE_END)
};
static CMD_ROUTE_T hw_nrsv_cmd =
{
	(UNS_8 *) "nrsv",
	cmd_nrsv,
	(UNS_8 *) "Reserve a range of blocks for WinCE",
	(UNS_8 *) "nrsv [first block] [number of blocks]",
	cmd_nrsv_plist,
	NULL
};

/* nandrs command */
BOOL_32 cmd_nandrs(void);
static UNS_32 cmd_nandrs_plist[] =
{
	(PARSE_TYPE_STR | PARSE_TYPE_END) /* The "nandrs" command */
};
static CMD_ROUTE_T hw_nandrs_cmd =
{
	(UNS_8 *) "nandrs",
	cmd_nandrs,
	(UNS_8 *) "Displays a list of reserved NAND blocks",
	(UNS_8 *) "nandrs",
	cmd_nandrs_plist,
	NULL
};

/* nexdump command */
BOOL_32 cmd_nexdump(void);
static UNS_32 cmd_nexdump_plist[] =
{
	(PARSE_TYPE_STR), /* The "nexdump" command */
	(PARSE_TYPE_DEC),
	(PARSE_TYPE_DEC | PARSE_TYPE_END)
};
static CMD_ROUTE_T hw_nexdump_cmd =
{
	(UNS_8 *) "nexdump",
	cmd_nexdump,
	(UNS_8 *) "Displays 'extra' data for a number of sectors",
	(UNS_8 *) "nexdump [first sector] [number of sectors]",
	cmd_nexdump_plist,
	NULL
};
#endif

static UNS_8 updnotc_msg[] = "Image in memory is not contiguous";
static UNS_8 updnoim_msg[] = "No image in memory to update NAND";
static UNS_8 updnotraw_msg[] = "Only raw images can be updated in NAND";
static UNS_8 updgt31_msg[] =
    "Image is too big for kickstart, must be less than 54K bytes";
static UNS_8 updgt256_msg[] =
    "Image is too big for stage 1, must be less than 256Kbytes";
static UNS_8 updfail_msg[] = "NAND bootloader update failed";
static UNS_8 updgood_msg[] = "Update completed";

#if 0
static UNS_8 blkmkerr_msg[] = "Error marking block(s)";
static UNS_8 rsvlist_msg[] = "Displaying NAND reserved block list";
#endif

extern UNS_8 noflash_msg[];




/***********************************************************************
 *
 * Function: cmd_update
 *
 * Purpose: Updates the stage 1 bootloader
 *
 * Processing:
 *     See function.
 *
 * Parameters: None
 *
 * Outputs: None
 *
 * Returns: Always returns TRUE.
 *
 * Notes: None
 *
 **********************************************************************/
BOOL_32 cmd_update(void) 
{
	BOOL_32 updated = FALSE;

	/* Is an image in memory? */
	if (sysinfo.lfile.flt == FLT_NONE) 
	{
		term_dat_out_crlf(updnoim_msg);
		return TRUE;
	}

	/* Is an image in memory a raw image? */
	if (sysinfo.lfile.flt != FLT_RAW) 
	{
		term_dat_out_crlf(updnotraw_msg);
		return TRUE;
	}

	/* Is the image in memory contiguous? */
	if (sysinfo.lfile.contiguous == FALSE) 
	{
		term_dat_out_crlf(updnotc_msg);
		return TRUE;
	}

	/* Is the image for stage 1 or the kickstart loader */
	if (parse_get_entry_count() == 2) 
	{
		/* Get passed command */
		if (str_cmp(get_parsed_entry(1), "kick") == 0) 
		{
			/* Updating block 0, does the image exceed 54K? */
			if (sysinfo.lfile.num_bytes > (54 * 1024)) 
			{
				term_dat_out_crlf(updgt31_msg);
				return TRUE;
			}
			else 
			{
				updated = nand_kickstart_update();
			}
		}
	}
	else 
	{
		/* Updating block 0, does the image exceed 256K? */
		if (sysinfo.lfile.num_bytes > (256 * 512)) 
		{
			term_dat_out_crlf(updgt256_msg);
			return TRUE;
		}
		else 
		{
			updated = nand_bootloader_update();
		}
	}

	/* Image in memory passes all checks, FLASH it at start of
	   block 0 */
	if (updated == FALSE) 
	{
		term_dat_out_crlf(updfail_msg);
	}
	else 
	{
		term_dat_out_crlf(updgood_msg);
	}

	return TRUE;
}

#if 0
/***********************************************************************
 *
 * Function: cmd_nrsv
 *
 * Purpose: Reserve a range of blocks for WinCE
 *
 * Processing:
 *     See function.
 *
 * Parameters: None
 *
 * Outputs: None
 *
 * Returns: Always returns TRUE
 *
 * Notes: None
 *
 **********************************************************************/
BOOL_32 cmd_nrsv(void) 
{
	UNS_32 lblock, fblock, nblks;

	/* Get arguments */
	fblock = cmd_get_field_val(1);
	nblks = cmd_get_field_val(2);

	/* Limit range outside of boot blocks */
	if (fblock < BL_NUM_BLOCKS)
	{
		/* Boot blocks are already marked as reserved, so skip them */

		/* Get last block to mark */
		lblock = (fblock + nblks) - 1;
		if (lblock < BL_NUM_BLOCKS)
		{
			nblks = 0;
		}
		else
		{
			fblock = 25;
			nblks = (lblock - fblock) + 1;
		}
	}

	/* Mark all of the blocks, skipping bad blocks */
	while (nblks > 0)
	{
		if (flash_reserve_block(fblock) == FALSE)
		{
			term_dat_out_crlf(blkmkerr_msg);
			nblks = 0;
		}
		else
		{
			fblock++;
			nblks--;
		}
	}

	return TRUE;
}

/***********************************************************************
 *
 * Function: cmd_nandrs
 *
 * Purpose: Displays a list of reserved NAND blocks
 *
 * Processing:
 *     See function.
 *
 * Parameters: None
 *
 * Outputs: None
 *
 * Returns: Always returns TRUE.
 *
 * Notes: None
 *
 **********************************************************************/
BOOL_32 cmd_nandrs(void) 
{
	UNS_8 blk [16];
	UNS_32 idx = 0;
	UNS_32 fblock = 0, nblks = 0;
	BOOL_32 ct, newct;

	if (sysinfo.nandgood == FALSE)
	{
		term_dat_out(noflash_msg);
	}
	else 
	{
		term_dat_out_crlf(rsvlist_msg);
		ct = flash_is_rsv_block((UNS_32) idx);
		while (idx < sysinfo.nandgeom.blocks) 
		{
			/* Read "extra" data area */
			newct = flash_is_rsv_block((UNS_32) idx);
			if ((newct != ct) || (idx == (sysinfo.nandgeom.blocks - 1)))
			{
				if (ct == FALSE)
				{
					term_dat_out((UNS_8 *) "Nonreserved blocks : Blocks ");
				}
				else
				{
					term_dat_out((UNS_8 *) "Reserved blocks    : Blocks ");
				}

				if (idx == (sysinfo.nandgeom.blocks - 1))
				{
					nblks++;
				}

				str_makedec(blk, fblock);
				term_dat_out(blk);
				term_dat_out((UNS_8 *) " to ");
				str_makedec(blk, (fblock + nblks - 1));
				term_dat_out_crlf(blk);

				ct = newct;
				nblks = 0;
				fblock = (UNS_32) idx;
			}

			nblks++;
			idx++;
		}
	}

	return TRUE;
}

/***********************************************************************
 *
 * Function: cmd_nexdump
 *
 * Purpose: Dumps extra data for a range of sectors
 *
 * Processing:
 *     See function.
 *
 * Parameters: None
 *
 * Outputs: None
 *
 * Returns: Always returns TRUE.
 *
 * Notes: None
 *
 **********************************************************************/
BOOL_32 cmd_nexdump(void) 
{
	UNS_8 str [16];
	UNS_32 fsector, flast;
	int idx, mx = 0;

	fsector = cmd_get_field_val(1);
	flast = fsector + cmd_get_field_val(2);

	if (sysinfo.nandgood == FALSE)
	{
		term_dat_out(noflash_msg);
	}
	else 
	{
		while (fsector < flast) 
		{
			/* Read "extra" data area */
			flash_read_sector_w_extra(fsector, secdat, &secdat[512]);

			/* Dump data */
			term_dat_out("Sector : ");
			str_makedec(str, fsector);
			term_dat_out_crlf(str);

			for (idx = 512; idx < (512 + 16); idx++)
			{
				str_makehex(str, (UNS_32) secdat [idx], 2);
				term_dat_out(str);
				mx++;
				if ((mx == 8) || (idx == (512 + 16 - 1)))
				{
					mx = 0;
					term_dat_out_crlf("");
				}
				else
				{
					term_dat_out(" : ");
				}
			}

			fsector++;
		}
	}

	return TRUE;
}
#endif


/***********************************************************************
 *
 * Function: hw_cmd_group_init
 *
 * Purpose: Initialize hardware command group
 *
 * Processing:
 *     See function. 
 *
 * Parameters: None
 *
 * Outputs: None
 *
 * Returns: Nothing
 *
 * Notes: None
 *
 **********************************************************************/
void hw_cmd_group_init(void)
{
	/* Add hw group */
	cmd_add_group(&hw_group);

	/* Add commands to the hw group */

	cmd_add_new_command(&hw_group, &hw_update_cmd);
#if 0
	cmd_add_new_command(&nand_group, &hw_nrsv_cmd);
	cmd_add_new_command(&nand_group, &hw_nandrs_cmd);
	cmd_add_new_command(&nand_group, &hw_nexdump_cmd);
#endif
}

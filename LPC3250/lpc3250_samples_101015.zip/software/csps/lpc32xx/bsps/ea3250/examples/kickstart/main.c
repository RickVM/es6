/***********************************************************************
 * $Id::$
 *
 * Project: EA LPC3250 kickstart code
 *
 * Description:
 *     Bootloader that will reside in block 0 of the NAND flash.
 *     The only responsibility of this bootloader is to load the
 *     application stored in block 1 and onwards.
 *
 ***********************************************************************
 * Software that is described herein is for illustrative purposes only
 * which provides customers with programming information regarding the
 * products. This software is supplied "AS IS" without any warranties.
 * NXP Semiconductors assumes no responsibility or liability for the
 * use of the software, conveys no license or title under any patent,
 * copyright, or mask work right to the product. NXP Semiconductors
 * reserves the right to make changes in the software without
 * notification. NXP Semiconductors also make no representation or
 * warranty that such application will be suitable for the specified
 * use without further testing or modification.
 **********************************************************************/


#include <string.h>
#include <stdio.h>

#include "lpc_types.h"
#include "lpc_irq_fiq.h"
#include "lpc_arm922t_cp15_driver.h"
#include "ea3250_board.h"
#include "lpc32xx_intc_driver.h"
#include "lpc32xx_gpio_driver.h"
#include "lpc32xx_uart_driver.h"
#include "lpc32xx_uart_driver.h"
#include "lpc32xx_clkpwr_driver.h"
#include "lpc_string.h"

#include "lpc_nandflash_params.h"
#include "lpc32xx_clkpwr_driver.h"
#include "lpc32xx_gpio_driver.h"
#include "lpc32xx_dma_driver.h"
#include "lpc32xx_slcnand_driver.h"
#include "lpc32xx_mlcnand_driver.h"

#include "uart.h"

/* Prototype for external IRQ handler */
void lpc32xx_irq_handler(void);

/* Bring in external images */
extern UNS_32 app1_start, app1_end;
extern UNS_32 app2_start, app2_end;

/* Device handler */
static INT_32 mlcnanddev;

/* UART buffer */
static char buff[512];

const NANDFLASH_PARAM_T k9f1g08u0a_9 =
{
  BUS_WIDTH_8,                   /* Bus width */
  BLOCK_PAGE_LARGE,              /* Block page (small/large) */
  ADDR_CYCLES_4,                 /* Address cycles (3/4/5) */
};

/* NAND flash */
#define NAND_FLASH k9f1g08u0a_9

/* for LARGE page NAND the maximum size of boot app is 54K */
#define NAND_MAX_BOOT_SIZE_LARGE (54*1024)

/* 
 * For the K9F1G08U0A the number of blocks is 1024. 
 * 1024 * 128 K = 1Gbit (128 MB)
 */
#define NAND_NUMBER_BLOCKS 1024

/* good block marker */
#define NAND_GOOD_BLOCK_MARKER 0xff
/* bad block marker */
#define NAND_BAD_BLOCK_MARKER 0x77

/* number of pages per block */
#define NAND_PAGES_PER_BLOCK 64

/* the size of one block in bytes (the data portion of the block */
#define NAND_BLOCK_SIZE (LARGE_BLOCK_PAGE_MAIN_AREA_SIZE*NAND_PAGES_PER_BLOCK)

/* offset to bad block info*/
#define NAND_SAMSUNG_BAD_OFFSET 2048
#define NAND_MLC_BAD_OFFSET     2096

/* maximum amount of internal memory */
#define MCU_MAX_INT_MEMORY (256*1024)

/* maximum size of application 2 */
#define MAX_APP2_SIZE (MCU_MAX_INT_MEMORY-NAND_MAX_BOOT_SIZE_LARGE)

/* Sector buffer - data area plus spare area */
static UNS_16 f16page [LARGE_BLOCK_PAGE_SIZE / 2];
static UNS_8 app2Magic[] = {0xea, 0x34, 0xcb, 0x15};



/***********************************************************************
 *
 * Function: deadloop
 *
 * Purpose: Endless loop
 *
 * Processing:
 *     See function.
 *
 * Parameters: None
 *
 * Outputs: None
 *
 * Returns: Nothing
 *
 * Notes: None
 *
 **********************************************************************/
void deadloop(void)
{
	uart_output("Program halted...\r\n");
	while (1);
}

/***********************************************************************
 *
 * Function: nand_init
 *
 * Purpose: Initialize NAND
 *
 * Parameters: None
 *
 * Outputs: None
 *
 * Returns: STATUS
 *
 * Notes: None
 *
 **********************************************************************/
static STATUS nand_init(void)
{
  MLC_TIMING_T mt;
  UNS_32 flashid;
  UNS_32 clk;

  clkpwr_setup_nand_ctrlr(0, 0, 0);
  clkpwr_clk_en_dis(CLKPWR_NAND_MLC_CLK, 1);

  mlcnanddev = mlcnand_open(MLCNAND, (INT_32) &NAND_FLASH);
  if (mlcnanddev == 0)
  {
    uart_output("Error opening NAND driver\r\n");
    deadloop();
  }

  /* Setup NAND controller timing */

  clk = clkpwr_get_clock_rate(CLKPWR_NAND_MLC_CLK);

  mt.tcea_delay = (1 + (clk / EA_NAND_TCEA_DELAY));
  mt.busy_delay = (1 + (clk / EA_NAND_BUSY_DELAY));
  mt.nand_ta    = (1 + (clk / EA_NAND_NAND_TA));
  mt.r_high     = (1 + (clk / EA_NAND_RD_HIGH));
  mt.r_low      = (1 + (clk / EA_NAND_RD_LOW));
  mt.wr_high    = (1 + (clk / EA_NAND_WR_HIGH));
  mt.wr_low     = (1 + (clk / EA_NAND_WR_LOW));

  if (mlcnand_ioctl(mlcnanddev, MLC_SET_TIMING, (INT_32) &mt)
                    == _ERROR)
  {
    uart_output("Error setting NAND timing\r\n");
    return _ERROR;
  }

  /* Get NAND flash id */
  if (mlcnand_ioctl(mlcnanddev, MLC_READ_ID,
                    (INT_32) &flashid) == _ERROR)
  {
    uart_output("Error reading NAND ID\r\n");
    return _ERROR;
  }
  flashid = flashid & 0xFFFF;

  sprintf(buff, "Detected NAND Flash ID is: %x\r\n", flashid);
  uart_output((UNS_8*)buff);

  return _NO_ERROR;
}

/***********************************************************************
 *
 * Function: nand_read_pages
 *
 * Purpose: Read several pages from a block
 *
 * Parameters: 
 *    block:    block number
 *    page:     starting page number
 *    pBuffer:  buffer for read data
 *    ptr:      number of pages to read
 *
 * Outputs: None
 *
 * Returns: STATUS
 *
 * Notes: None
 *
 **********************************************************************/
static STATUS nand_read_pages(UNS_32 block, UNS_32 page, 
  UNS_8* pBuffer, UNS_32 ptr)
{
  MLC_BLOCKPAGE_T blockpage;
  UNS_8 *pagedat = (UNS_8 *) f16page;

  /* Store application in block 0, starting from page */ 
  blockpage.dma = 0;
  blockpage.block_num = block;
  blockpage.page_num = page;
  blockpage.buffer = pagedat;
  
  while(blockpage.page_num <= ptr)
  {
    int i = 0;
      
    memset(pagedat, 0x0, LARGE_BLOCK_PAGE_SIZE);

    if (mlcnand_ioctl(mlcnanddev, MLC_READ_PAGE,
                      (INT_32) &blockpage) == _ERROR)
    {
      sprintf(buff, "Error reading block %d, page %d\r\n", block, 
        blockpage.page_num);
      uart_output((UNS_8*)buff);
      return _ERROR;
    }

    for (i = 0; i < 4; i++)
    {
      /* skip spare area from each read section */

      memcpy(pBuffer, pagedat+(i*SMALL_BLOCK_PAGE_SIZE), 
        SMALL_BLOCK_PAGE_MAIN_AREA_SIZE);

        pBuffer += (SMALL_BLOCK_PAGE_MAIN_AREA_SIZE); 
    }

    blockpage.page_num++;
  }

  return _NO_ERROR;
}


/***********************************************************************
 *
 * Function: app2CheckMagicGetSizes
 *
 * Purpose: 
 *    Check if magic number is stored in block 1/page 0. If 
 *    if is available copy the size info to output parameter.
 *  
 *
 * Parameters: 
 *    sizes: size info will be copied here
 *
 * Outputs:
 *    Application size information 
 *
 * Returns: TRUE if the magic number is available; otherwise FALSE
 *
 * Notes: None
 *
 **********************************************************************/
static BOOL_32 app2CheckMagicGetSizes(UNS_32* sizes)
{
  BOOL_32 result = FALSE;
  MLC_BLOCKPAGE_T blockpage;
  UNS_8* buffer = (UNS_8*) f16page;

  blockpage.dma = 0;

  /* 
   * Here we assume that block 1 is always valid, which doesn't have 
   * to be the case. Should be changed so that the first valid block
   * after block 0 is used
   */
  blockpage.block_num = 1;
  blockpage.page_num = 0;
  blockpage.buffer = (UNS_8 *) buffer;

  if (mlcnand_ioctl(mlcnanddev, MLC_READ_PAGE,
                    (INT_32) &blockpage) == _ERROR)
  {
    uart_output("Error reading block 1, page 0\r\n");
    goto failed;
  }

  if (memcmp(app2Magic, buffer, sizeof(app2Magic)) == 0)
    result = TRUE;
  
  if (sizes != NULL)
    memcpy(sizes, buffer+sizeof(app2Magic), sizeof(UNS_32)*2);

failed:

  return result;
}



/***********************************************************************
 *
 * Function: app2IsBlockInvalid
 *
 * Purpose: Check if a block is marked as invalid (bad)
 *
 * Parameters: 
 *    blockNum:  The block number to check
 *
 * Outputs: None
 *
 * Returns:
 *    TRUE if it is invalid; otherwise FALSE 
 *
 * Notes: None
 *
 **********************************************************************/
static BOOL_32 app2IsBlockInvalid(UNS_32 blockNum)
{
  BOOL_32 result = TRUE;
  MLC_BLOCKPAGE_T blockpage;
  UNS_8* buffer = (UNS_8*) f16page;

  blockpage.dma = 0;
  blockpage.buffer = (UNS_8 *) buffer;
  blockpage.block_num = blockNum;
  blockpage.page_num = 0;

  if (mlcnand_ioctl(mlcnanddev, MLC_READ_PAGE,
                        (INT_32) &blockpage) == _ERROR)
  {
    sprintf(buff, "Error reading block %d, page 0\r\n", blockNum);
    uart_output((UNS_8*)buff);    
    goto failed;
  }

  result = (buffer[NAND_MLC_BAD_OFFSET] == NAND_BAD_BLOCK_MARKER);

failed:

  return result;
}


static STATUS app2ReadAppData(UNS_8* pBuffer, UNS_32 appSize)
{
  STATUS status = _ERROR;
  UNS_32 blockNum = 1;
  UNS_32 page = 1;
  UNS_32 ptr = 0;
  UNS_32 dataRead = 0;

  while(dataRead < appSize)
  {
    /* if a block is invalid skip it */
    if (app2IsBlockInvalid(blockNum))
    {
      blockNum++;
      continue;
    }

    ptr = (appSize-dataRead) / LARGE_BLOCK_PAGE_MAIN_AREA_SIZE;
    if (ptr*LARGE_BLOCK_PAGE_MAIN_AREA_SIZE < (appSize-dataRead))
      ptr++;

    if (ptr > (NAND_PAGES_PER_BLOCK-page))
      ptr = (NAND_PAGES_PER_BLOCK-page);  

    if (nand_read_pages(blockNum, page, 
      pBuffer+dataRead, ptr) != _NO_ERROR)
    {
      sprintf(buff, "Failed to read pages in block %d\r\n", blockNum);
      uart_output((UNS_8*)buff);
      goto failed;    
    }

    dataRead += (ptr*LARGE_BLOCK_PAGE_MAIN_AREA_SIZE);
    blockNum++;
    page = 0;    
  }
  status = _NO_ERROR;
         
failed:

  return status;
}



/***********************************************************************
 *
 * Function: c_entry
 *
 * Purpose: Application entry point from the startup code
 *
 * Processing:
 *     See function.
 *
 * Parameters: None
 *
 * Outputs: None
 *
 * Returns: Always returns 1, or <0 on an error
 *
 * Notes: None
 *
 **********************************************************************/
void c_entry(void)
{
  UNS_8* pMem = (UNS_8*) 0x00000000;
  UNS_32 sizes[2];
  PFV execa = (PFV) 0x00000000;
  
  /* Disable interrupts in ARM core */
  disable_irq_fiq();

  /* Setup miscellaneous board functions */
  ea3250_board_init();

  /* Set virtual address of MMU table */
  cp15_set_vmmu_addr((void *)
                     (IRAM_BASE + (256 * 1024) - (16 * 1024)));

  /* Initialize interrupt system */
  int_initialize(0xFFFFFFFF);

    
  /* Enable interrupts in ARM core */
  enable_irq_fiq();

  uart_output_init();

  
  uart_output("Kickstart bootloader started...\r\n");
  do {
    if (nand_init() != _NO_ERROR) {
      break;
    }

    if (!app2CheckMagicGetSizes(sizes))
    {
      uart_output("No magic number available, exiting\r\n");
      break;                                                
    }

    if (sizes[0] != (0xFFFFFFFF - sizes[1]))
    {
      sprintf(buff, "Size information is not valid (%d)\r\n", sizes[0]);
      uart_output((UNS_8*)buff);
      break;                                                
    }

    if (sizes[0] > MAX_APP2_SIZE)
    {
      sprintf(buff, "Size of app2 is too large (%d > %d)\r\n", 
        sizes[0], MAX_APP2_SIZE);
      uart_output((UNS_8*)buff);
      break;                                                
    }

    uart_output("Kickstart: reading application data\r\n");
    if (app2ReadAppData(pMem, sizes[0]) != _NO_ERROR)
      break;

    uart_output("Kickstart: starting application\r\n");
    execa();

  } while (FALSE);


}

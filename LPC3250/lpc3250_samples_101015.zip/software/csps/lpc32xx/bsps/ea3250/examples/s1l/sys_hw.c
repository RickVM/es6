/***********************************************************************
 * $Id:: sys_hw.c 977 2008-07-29 18:30:15Z wellsk                      $
 *
 * Project: NXP PHY3250 startup code for stage 1
 *
 * Description:
 *     This file provides initialization code for the S1L.
 *
 ***********************************************************************
 * Software that is described herein is for illustrative purposes only  
 * which provides customers with programming information regarding the  
 * products. This software is supplied "AS IS" without any warranties.  
 * NXP Semiconductors assumes no responsibility or liability for the 
 * use of the software, conveys no license or title under any patent, 
 * copyright, or mask work right to the product. NXP Semiconductors 
 * reserves the right to make changes in the software without 
 * notification. NXP Semiconductors also make no representation or 
 * warranty that such application will be suitable for the specified 
 * use without further testing or modification. 
 **********************************************************************/

#include "lpc_types.h"
#include "ea3250_board.h"
#include "ea3250_spinor.h"
#include "lpc_arm922t_cp15_driver.h"
#include "lpc32xx_clkpwr_driver.h"
#include "s1l_sys_inf.h"
#include "lpc_string.h"
#include "s1l_sys.h"
#include "sys.h"
#include "ea3250_nand_boot.h"



volatile UNS_32 tick_10ms;

/* Invalidate instruction cache */
void icache_invalid(void)
{
	cp15_invalidate_cache();
}


/***********************************************************************
 *
 * Function: svinfockgood
 *
 * Purpose: Verifies savedinfo structure is good
 *
 * Processing:
 *     See function.
 *
 * Parameters: TBD
 *
 * Outputs: None
 *
 * Returns: TRUE if the structure is good, otherwise FALSE
 *
 * Notes: None
 *
 **********************************************************************/
BOOL_32 svinfockgood(UNS_32 *buff,
							int bytes,
							UNS_32 verikey) 
{
	BOOL_32 goodinfo = FALSE;
	UNS_32 genck = 0;
	int sz = bytes / sizeof(UNS_32);
	while (sz > 0) 
	{
		genck = genck + *buff;
		buff++;
		sz--;
	}

	if ((genck ^ verikey) == 0xFFFFFFFF) 
	{
		goodinfo = TRUE;
	}

	return goodinfo;
}

/***********************************************************************
 *
 * Function: svinfockgen
 *
 * Purpose: Generate verification key for savedinfo structure
 *
 * Processing:
 *     See function.
 *
 * Parameters: TBD
 *
 * Outputs: None
 *
 * Returns: Nothing
 *
 * Notes: None
 *
 **********************************************************************/
void svinfockgen(UNS_32 *buff,
						int bytes,
						UNS_32 *verikey) 
{
	UNS_32 genck = 0;
	int sz = bytes / sizeof(UNS_32);
	while (sz > 0) 
	{
		genck = genck + *buff;
		buff++;
		sz--;
	}

	*verikey = ~genck;
}


/***********************************************************************
 *
 * Function: nand_bootloader_update
 *
 * Purpose:
 *     Places a new bootloader into the first block(s).
 *
 * Processing:
 *     See function.
 *
 * Parameters: None
 *
 * Outputs: None
 *
 * Returns: TRUE if the NAND was updated, otherwise FALSE
 *
 * Notes: Will overwrite the bootloader. Be careful.
 *
 **********************************************************************/
BOOL_32 nand_bootloader_update(void) 
{

  BOOL_32 result = FALSE;  
  
  /* disable the flash code since MLC is going to be used */
  flash_deinit();

  do {

    if (nand_boot_init() != _NO_ERROR)
    {
      break;
    }

    if (nand_boot_store_app2((UNS_8*)sysinfo.lfile.loadaddr, 
      sysinfo.lfile.num_bytes) != _NO_ERROR)
    {
      break;
    }

    result = TRUE;

  } while (FALSE);

  nand_boot_deinit();

  /* initialize the flash code again */
  flash_init(NULL);

  return result;
}

/***********************************************************************
 *
 * Function: nand_kickstart_update
 *
 * Purpose:
 *     Places a new kickstart loader into the first block.
 *
 * Processing:
 *     See function.
 *
 * Parameters: None
 *
 * Outputs: None
 *
 * Returns: TRUE if the NAND was updated, otherwise FALSE
 *
 * Notes: WIll overwrite the kickstart code in block 0. Be careful.
 *
 **********************************************************************/
BOOL_32 nand_kickstart_update(void) 
{
  BOOL_32 result = FALSE;  
  
  /* disable the flash code since MLC is going to be used */
  flash_deinit();

  do {

    if (nand_boot_init() != _NO_ERROR)
    {
      break;
    }

    if (nand_boot_store_app1((UNS_8*)sysinfo.lfile.loadaddr, 
      sysinfo.lfile.num_bytes) != _NO_ERROR)
    {
      break;
    }

    result = TRUE;

  } while (FALSE);

  nand_boot_deinit();

  /* initialize the flash code again */
  flash_init(NULL);

  return result;
}


/***********************************************************************
 *
 * Function: c_entry
 *
 * Purpose: Application entry point from the startup code
 *
 * Processing:
 *     See function.
 *
 * Parameters: None
 *
 * Outputs: None
 *
 * Returns: Nothing
 *
 * Notes: None
 *
 **********************************************************************/
void c_entry(void) {
	BOOL_32 goto_prompt = TRUE;

  spinor_init();

	while (1) 
	{
		/* Go to boot manager */
		boot_manager(goto_prompt);
		goto_prompt = FALSE;
	}
}

/***********************************************************************
 * $Id:: sysapi_flash.c 1276 2008-10-30 00:07:49Z wellsk               $
 *
 * Project: System configuration save and restore functions
 *
 * Description:
 *     Implements the following functions required for the S1L API
 *         cfg_save
 *         cfg_load
 *         cfg_override
 *
 ***********************************************************************
 * Software that is described herein is for illustrative purposes only  
 * which provides customers with programming information regarding the  
 * products. This software is supplied "AS IS" without any warranties.  
 * NXP Semiconductors assumes no responsibility or liability for the 
 * use of the software, conveys no license or title under any patent, 
 * copyright, or mask work right to the product. NXP Semiconductors 
 * reserves the right to make changes in the software without 
 * notification. NXP Semiconductors also make no representation or 
 * warranty that such application will be suitable for the specified 
 * use without further testing or modification. 
 **********************************************************************/

#include "lpc_string.h"
#include "sys.h"
#include "s1l_sys.h"
#include "s1l_sys_inf.h"
#include "ea3250_board.h"
#include "lpc32xx_slcnand.h"
#include "lpc32xx_clkpwr.h"
#include "lpc32xx_clkpwr_driver.h"
#include "lpc_nandflash_params.h"
#include "ea3250_board.h"
#include "lpc_lbecc.h"
#include "lpc_nandflash_params.h"
#include "lpc32xx_dma_driver.h"
#include "lpc32xx_slcnand_driver.h"

static FLASH_GEOM_T nandgeom;
static UNS_8 nanddevid[5];
static UNS_8 flash_buf[LARGE_BLOCK_PAGE_SIZE];

static INT_32 slcnanddev;

static const NANDFLASH_PARAM_T k9f1g08u0a_9 =
{
  BUS_WIDTH_8,                   /* Bus width */
  BLOCK_PAGE_LARGE,              /* Block page (small/large) */
  ADDR_CYCLES_4,                 /* Address cycles (3/4/5) */
};

/* SLC NAND flash */
#define SLCNAND_FLASH k9f1g08u0a_9

/* Initialize NAND device and populate NAND structure */
BOOL_32 flash_init(FLASH_GEOM_T *pNand)
{
  SLC_TAC_T tac;
  BOOL_32 result = FALSE;

	/* Initialize ECC */
	//lpc_eccinittables();

  dma_init();

  slcnanddev = slcnand_open(SLCNAND, (INT_32) &SLCNAND_FLASH);
  if (slcnanddev == 0)
    return FALSE;

  /* Setup SLC NAND controller timing */
  tac.w_rdy = 14;
  tac.w_width = 5;
  tac.w_hold = 2;
  tac.w_setup = 1;
  tac.r_rdy = 14;
  tac.r_width = 4;
  tac.r_hold = 2;
  tac.r_setup = 1;

  if (slcnand_ioctl(slcnanddev, SLC_SET_TIMING, (INT_32) &tac)
                    == _ERROR)
  {
    term_dat_out("flash_init: Error setting SLC NAND timing\r\n");
    goto failed;
  }

  /* Get SLC NAND flash id */
  if (slcnand_ioctl(slcnanddev, SLC_READ_ID,
                    (INT_32) nanddevid) == _ERROR)
  {
    term_dat_out("flash_init: Error reading NAND ID\r\n");
    goto failed;
  }

  if (nanddevid[0] != LPCNAND_VENDOR_SAMSUNG)
  {
    term_dat_out("flash_init: NAND flash vendor NOT Samsung\r\n");
    goto failed;
  }


  // Only support for the Samsung 128 MB flash ...
  nandgeom.blocks                = 1024;
  nandgeom.sectors_per_block     = 64;
  nandgeom.data_bytes_per_sector = 2048;
  nandgeom.addrcycles            = 4;

  if (pNand != NULL)
  {
    pNand->blocks = nandgeom.blocks;
    pNand->sectors_per_block = nandgeom.sectors_per_block;
    pNand->data_bytes_per_sector =  nandgeom.data_bytes_per_sector;
    pNand->addrcycles = nandgeom.addrcycles;    
  }

  result = TRUE;

  goto ok;
failed:
  slcnand_close(slcnanddev);
ok:  

  return result;
}

/* De-initialize FLASH */
void flash_deinit(void)
{
  slcnand_close(slcnanddev);
}


//static UNS_32 ecc_buffer[10];
//static DMAC_LL_T dma_list11[16];
/* Read a NAND sector */
BOOL_32 flash_read_sector(UNS_32 sector,
						  void *buff)
{
  SLC_BLOCKPAGE_T blockpage;

//  blockpage.dma = dma_list11;
//  blockpage.ecc = ecc_buffer;
  blockpage.dma = 0;
  blockpage.ecc = 0;

  blockpage.block_num = sector / nandgeom.sectors_per_block;;
  blockpage.page_num = sector - (blockpage.block_num * nandgeom.sectors_per_block);

  blockpage.buffer = (UNS_8 *) buff;

  if (slcnand_ioctl(slcnanddev, SLC_READ_PAGE,
                  (INT_32) &blockpage) == _ERROR)
  {
    term_dat_out("flash_read_sector: Error reading\r\n");
    return FALSE;
  }

  return TRUE;
}


/* Write a NAND sector */

BOOL_32 flash_write_sector(UNS_32 sector,
						   void *buff)
{
  SLC_BLOCKPAGE_T blockpage;

//  blockpage.dma = dma_list;
//  blockpage.ecc = ecc_buffer;
  blockpage.dma = 0;
  blockpage.ecc = 0;

  blockpage.block_num = sector / nandgeom.sectors_per_block;;
  blockpage.page_num = sector - (blockpage.block_num * nandgeom.sectors_per_block);

  blockpage.buffer = (UNS_8 *) buff;

  if (slcnand_ioctl(slcnanddev, SLC_WRITE_PAGE_NO_SPARE,
                  (INT_32) &blockpage) == _ERROR)
  {
    term_dat_out("flash_write_sector: Error writing\r\n");
    return FALSE;
  }

  return TRUE;
}

/* Marks a block as bad, support function */

static BOOL_32 flash_mark_bad_block(UNS_32 block)
{
  SLC_BLOCKPAGE_T blockpage;

  blockpage.dma = 0;
  blockpage.ecc = 0;
  blockpage.block_num = block;
  blockpage.page_num  = 0;

  blockpage.buffer = (UNS_8 *) flash_buf;

  if (slcnand_ioctl(slcnanddev, SLC_READ_PAGE,
                  (INT_32) &blockpage) == _ERROR)
  {
    term_dat_out("flash_mark_bad_block: Error reading\r\n");
    return FALSE;
  }

  /* index 0 of the spare area. bad value is anyting != 0xff */
  flash_buf[LARGE_BLOCK_PAGE_MAIN_AREA_SIZE+0] = 0x77;

  if (slcnand_ioctl(slcnanddev, SLC_WRITE_PAGE,
                  (INT_32) &blockpage) == _ERROR)
  {
    term_dat_out("flash_mark_bad_block: Error reading\r\n");
    return FALSE;
  }

  return TRUE;
  
}


/* Erase a block */

BOOL_32 flash_erase_block(UNS_32 block,
						  BOOL_32 override)
{
  UNS_8 blk[16];

	if (override == FALSE)
	{
		if (flash_is_bad_block(block) == TRUE)
		{
			return FALSE;
		}
	}

  if (slcnand_ioctl(slcnanddev, SLC_ERASE_BLOCK, block) == _ERROR)
  {
    term_dat_out("flash_erase_block: Error erasing block ");
    str_makedec(blk, block);
    term_dat_out(blk);
    term_dat_out("\r\n");
    
    // Mark block as bad
	  flash_mark_bad_block(block);
    
    return FALSE;
  }

  return TRUE;
}

/* Returns TRUE if the current block is a bad block */
BOOL_32 flash_is_bad_block(UNS_32 block)
{
  SLC_BLOCKPAGE_T blockpage;
  UNS_8 spare[LARGE_BLOCK_PAGE_SPARE_AREA_SIZE];

  blockpage.dma = 0;
  blockpage.ecc = 0;

  blockpage.block_num = block;
  blockpage.page_num = 0;

  blockpage.buffer = (UNS_8 *) spare;

  if (slcnand_ioctl(slcnanddev, SLC_READ_SPARE,
                  (INT_32) &blockpage) == _ERROR)
  {
    term_dat_out("flash_is_bad_block: Failed reading spare\r\n");
    return FALSE;
  }

  return (spare[0] != 0xFF);
}

/* Returns the NAND vendor and device ID */
void flash_get_id(UNS_8 *nvendor, UNS_8 *nid)
{
	*nvendor = nanddevid[0];
	*nid = nanddevid[1];
}


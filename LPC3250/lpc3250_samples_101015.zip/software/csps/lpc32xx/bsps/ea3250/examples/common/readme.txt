$Id:: readme.txt 450 2008-03-25 18:05:15Z wellsk                       $

Code is this common directory is used by other examples and is not
directly buildable or executable.

s1l
---

This is an example of the S1L bootloader. By default this
bootloader is stored in the NAND flash on the Embedded Artists
LPC3250 OEM Board and is loaded by the kickstart (examples/kickstart)
bootloader.

The kickstart bootloader (stored in NAND block 0) will be loaded
by the embedded bootloader on the LPC3250 MCU. 

The examples/nand_prog application is used to program the kickstart
and s1l applications into NAND flash.

Read the ea3250/docs/lpc32xx_bl.pdf document for more information.
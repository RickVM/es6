/***********************************************************************
 * $Id::$
 *
 * Project: Program the NAND flash with two applications.
 *
 * Description:
 *    First application written to block 0. This block can directly
 *    be used by the LPC3250 bootloader to load an application. 
 *    This application should typically be the kickstart 
 *    bootloader that can then be used to load a larger 
 *    application from block 1 and onwards.
 *
 *    The second application may occupy several blocks starting
 *    from block 1. This application could for example be a more
 *    advanced bootloader such as the s1l.
 *
 ***********************************************************************
 * Software that is described herein is for illustrative purposes only
 * which provides customers with programming information regarding the
 * products. This software is supplied "AS IS" without any warranties.
 * NXP Semiconductors assumes no responsibility or liability for the
 * use of the software, conveys no license or title under any patent,
 * copyright, or mask work right to the product. NXP Semiconductors
 * reserves the right to make changes in the software without
 * notification. NXP Semiconductors also make no representation or
 * warranty that such application will be suitable for the specified
 * use without further testing or modification.
 **********************************************************************/


#include <string.h>
#include <stdio.h>

#include "lpc_types.h"
#include "lpc_irq_fiq.h"
#include "lpc_arm922t_cp15_driver.h"
#include "ea3250_board.h"
#include "lpc32xx_intc_driver.h"
#include "lpc32xx_gpio_driver.h"
#include "lpc32xx_uart_driver.h"
#include "lpc32xx_uart_driver.h"
#include "lpc32xx_clkpwr_driver.h"
#include "lpc_string.h"

#include "lpc_nandflash_params.h"
#include "lpc32xx_clkpwr_driver.h"
#include "lpc32xx_gpio_driver.h"
#include "lpc32xx_dma_driver.h"
#include "lpc32xx_slcnand_driver.h"
#include "lpc32xx_mlcnand_driver.h"
#include "ea3250_nand_boot.h"

#include "uart.h"

/* Prototype for external IRQ handler */
void lpc32xx_irq_handler(void);

/* Bring in external images */
extern UNS_32 kickstart_start, kickstart_end;
extern UNS_32 app2_start, app2_end;


/* UART buffer */
static char buff[512];



/***********************************************************************
 *
 * Function: c_entry
 *
 * Purpose: Application entry point from the startup code
 *
 * Processing:
 *     See function.
 *
 * Parameters: None
 *
 * Outputs: None
 *
 * Returns: Always returns 1, or <0 on an error
 *
 * Notes: None
 *
 **********************************************************************/
void c_entry(void)
{
  UNS_32 *a1, *a2;
  
  /* Disable interrupts in ARM core */
  disable_irq_fiq();

  /* Setup miscellaneous board functions */
  ea3250_board_init();

  /* Set virtual address of MMU table */
  cp15_set_vmmu_addr((void *)
                     (IRAM_BASE + (256 * 1024) - (16 * 1024)));

  /* Initialize interrupt system */
  int_initialize(0xFFFFFFFF);

  /* Setup DMA */
  dma_init();

  /* Enable interrupts in ARM core */
  enable_irq_fiq();

  uart_output_init();  

  do {
    if (nand_boot_init() != _NO_ERROR)
      break;

    a2 = &kickstart_end;
    a1 = &kickstart_start;

    uart_output("Writing kickstart data\r\n");
   
    if (nand_boot_store_app1((UNS_8*)*a1, ((UNS_32) *a2 - (UNS_32) *a1)) != _NO_ERROR)
      break;

    a2 = &app2_end;
    a1 = &app2_start;

    uart_output("Writing app 2\r\n");

    if (nand_boot_store_app2((UNS_8*)*a1, ((UNS_32) *a2 - (UNS_32) *a1)) != _NO_ERROR)
    {
      break;
    }

    uart_output("Done\r\n");

  } while (FALSE);


  /* Loop forever */
  while (1);
}

$Id:: lpc32x0_loader_readme.txt 1235 2008-10-24 16:15:18Z wellsk       $

LPC3250 loader

See the documentation included in the DOC directory for how to use
this tool.

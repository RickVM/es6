$Id:: lpc32xx_readme.txt 1241 2008-10-24 17:04:53Z wellsk              $

NXP LPC32xx Chip Support Package version 1.01

************************************************************************
************************************************************************
* SUpported chip peripherals of the CSP
************************************************************************
************************************************************************
This CSP contains driver support for the following chip peripherals:
 * LPC32xx ADC/Touchscreen
 * LPC32xx Color LCD controller
 * LPC32xx Clock and power controller
 * LPC32xx DMA controller (channel allocation driver only)
 * LPC32xx GPIO controller
 * LPC32xx I2S audio
 * LPC32xx Interrupt controller
 * LPC32xx Keyboard scanner
 * LPC32xx Millisecond timer
 * LPC32xx Real time clock (RTC)
 * LPC3xxx SD card controller
 * LPC32xx SSP 0/1
 * LPC32xx standard timers 0/1/2/3
 * LPC32xx UARTs 3/4/5/6
 * LPC32xx PWM
 * LPC32xx SLC NAND controller
 * LPC32xx MLC NAND controller

************************************************************************
************************************************************************
* Toolchain support
************************************************************************
************************************************************************
* ARM Realview support
************************************************************************
This package works under ARM Realview 3.x.

************************************************************************
* CodeSourcery GCC support
************************************************************************
This package works under CodeSourcery GCC.

************************************************************************
* ARM Developer's Suite support
************************************************************************
Support for Arm Developer's Suite has not been fully tested and may
only be partially available.

************************************************************************
* IAR Embedded Workbench support
************************************************************************
This package works under IAR EMbedded Workbench.

************************************************************************
* Keil support
************************************************************************
This package works under Keil uVision3.

************************************************************************
************************************************************************
* Known issues
************************************************************************
************************************************************************
No known issues

************************************************************************
************************************************************************
* Package history
************************************************************************
************************************************************************
Version 1.00
 Initial NXP release.

Version 1.01
 Serial loader tool added to BSP (and associated documentation)
